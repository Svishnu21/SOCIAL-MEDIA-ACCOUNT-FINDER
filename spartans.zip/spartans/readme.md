# Vervathon-2023

## Team Name - SPARTANS
### Problem Statement - (2) SOCIAL MEDIA ACCOUNT IDENTIFIER (FSO - CYBER PRIVACY)
### Team Leader Email - svishnubtechit@gmail.com

---

## A Brief of the Prototype:
  ![Load Image](/static/usecasediagram.png)
  

## Tech Stack: 
 - python
   - flask
   - subprocess
   - requests
   - sqlite3
 - HTML, CSS, JS
 - SQL
   
---


## Step-by-Step Code Execution Instructions:
  1. Clone this repo.
  2. Ensure that you have python >= 3.10\
  3. Open cmd in the current directory.
  4. run:  ```py main.py``` 
  
---

## What I Learned:
   The important thing I have to mention about is that, we have improved our coordination and team work skills. We also learned that the websites that we login can make our login information publicly available. We also learned how to execute `.exe` files using subprocess and get the result in a file.

---

## Team Members
```
 - Parvat R (CSE 2nd Year)
 - Vishnu S (IT 2nd Year)
 - Santhosh S (CSE 2nd Year)
```
---
###### Credits: `@megadose->holehe`